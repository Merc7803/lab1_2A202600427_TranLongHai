# Ngày 1 — Bài Tập & Phản Ánh
## Nền Tảng LLM API | Phiếu Thực Hành

**Thời lượng:** 1:30 giờ  
**Cấu trúc:** Lập trình cốt lõi (60 phút) → Bài tập mở rộng (30 phút)

---

## Phần 1 — Lập Trình Cốt Lõi (0:00–1:00)

Chạy các ví dụ trong Google Colab tại: https://colab.research.google.com/drive/172zCiXpLr1FEXMRCAbmZoqTrKiSkUERm?usp=sharing

Triển khai tất cả TODO trong `template.py`. Chạy `pytest tests/` để kiểm tra tiến độ.

**Điểm kiểm tra:** Sau khi hoàn thành 4 nhiệm vụ, chạy:
```bash
python template.py
```
Bạn sẽ thấy output so sánh phản hồi của GPT-4o và GPT-4o-mini.

---

## Phần 2 — Bài Tập Mở Rộng (1:00–1:30)

### Bài tập 2.1 — Độ Nhạy Của Temperature
Gọi `call_openai` với các giá trị temperature 0.0, 0.5, 1.0 và 1.5 sử dụng prompt **"Hãy kể cho tôi một sự thật thú vị về Việt Nam."**

**Bạn nhận thấy quy luật gì qua bốn phản hồi?** (2–3 câu)
> Khi temperature thấp (0.0-0.5), câu trả lời rất ổn định và tập trung vào một thông tin cụ thể. Khi tăng temperature lên (1.0-1.5), nội dung bắt đầu đa dạng hơn, mỗi lần có thể đề cập đến các chủ đề khác nhau như cà phê trứng hay di sản văn hóa. Ở mức càng cao câu trả lời càng trở nên sáng tạo và phong phú hơn, mở rộng sang nhiều khía cạnh khác nhau.

**Bạn sẽ đặt temperature bao nhiêu cho chatbot hỗ trợ khách hàng, và tại sao?**
> Đặt temprature ở mức thấp (0.0-0.5). Vì chatbot hỗ trợ khách hàng cần đưa ra cầu trả lời tập trung vào vấn đề khách hàng quan tâm, tránh việc nói lan man và đưa ra thông tin ngoài lề.

---

### Bài tập 2.2 — Đánh Đổi Chi Phí
Xem xét kịch bản: 10.000 người dùng hoạt động mỗi ngày, mỗi người thực hiện 3 lần gọi API, mỗi lần trung bình ~350 token.

**Ước tính xem GPT-4o đắt hơn GPT-4o-mini bao nhiêu lần cho workload này:**
> Giả sử toàn bộ là output tokens:
Số request mỗi ngày:
10.000 users × 3 = 30.000 requests
Tổng token mỗi ngày:
30.000 × 350 = 10.500.000 tokens (~10.5M tokens)

GPT-4o:
10.5M / 1M × $10 = $105 / ngày
GPT-4o-mini:
10.5M / 1M × $0.60 = $6.3 / ngày
->>GPT-4o đắt hơn ~16.7 lần

**Mô tả một trường hợp mà chi phí cao hơn của GPT-4o là xứng đáng, và một trường hợp GPT-4o-mini là lựa chọn tốt hơn:**
> - GPT-4o phù hợp khi cần độ chính xác và khả năng suy luận cao, ví dụ như phân tích dữ liệu phức tạp, hỗ trợ lập trình, hoặc trả lời các câu hỏi chuyên sâu. Trong những trường hợp này, chất lượng quan trọng hơn chi phí.
- GPT-4o-mini phù hợp với các tác vụ đơn giản, số lượng lớn như chatbot hỗ trợ khách hàng cơ bản, trả lời FAQ, hoặc xử lý văn bản đơn giản. Khi yêu cầu không quá phức tạp, dùng mini sẽ tiết kiệm chi phí đáng kể.

---

### Bài tập 2.3 — Trải Nghiệm Người Dùng với Streaming
**Streaming quan trọng nhất trong trường hợp nào, và khi nào thì non-streaming lại phù hợp hơn?** (1 đoạn văn)
> Streaming quan trọng nhất trong các ứng dụng cần phản hồi nhanh và cần theo thời gian thực cho người dùng, như chatbot, trợ lý AI hoặc khi sinh nội dung dài, vì người dùng có thể thấy kết quả ngay lập tức mà không phải chờ toàn bộ câu trả lời. Điều này giúp cải thiện trải nghiệm và giảm cảm giác chờ đợi. Ngược lại, non-streaming phù hợp hơn trong các trường hợp cần kết quả hoàn chỉnh trước khi xử lý tiếp, như gọi API backend, xử lý dữ liệu, hoặc khi cần đảm bảo tính toàn vẹn của toàn bộ phản hồi trước khi hiển thị.


## Danh Sách Kiểm Tra Nộp Bài
- [ ] Tất cả tests pass: `pytest tests/ -v`
- [ ] `call_openai` đã triển khai và kiểm thử
- [ ] `call_openai_mini` đã triển khai và kiểm thử
- [ ] `compare_models` đã triển khai và kiểm thử
- [ ] `streaming_chatbot` đã triển khai và kiểm thử
- [ ] `retry_with_backoff` đã triển khai và kiểm thử
- [ ] `batch_compare` đã triển khai và kiểm thử
- [ ] `format_comparison_table` đã triển khai và kiểm thử
- [ ] `exercises.md` đã điền đầy đủ
- [ ] Sao chép bài làm vào folder `solution` và đặt tên theo quy định 
